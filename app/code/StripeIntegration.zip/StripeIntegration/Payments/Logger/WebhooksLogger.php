<?php

namespace StripeIntegration\Payments\Logger;

class WebhooksLogger extends \Monolog\Logger
{
}
